# responsive-fixed-sidebar
 A pure css animated responsive sidebar
